a = float(input('Enter first side: '))
b = float(input('Enter second side: '))
c = float(input('Enter third side: '))
if (a**2 + b**2 == c**2):
    print("Entered triangle is right-angled triangle")
else:
    print("Entered triangle is not right-angled triangle")
    
s = (a + b + c) / 2

area = (s*(s - a)*(s - b)*(s - c)) ** 0.5
print(f"The area of triangle is {area} cm²")