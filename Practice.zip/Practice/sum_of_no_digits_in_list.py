test_list = [10,34,545,634,28]
print("The original list is : " + str(test_list))
res = []
for ele in test_list:
    sum = 0
    for digit in str(ele):
        sum += int(digit)
    res.append(sum)
print ("List after addition of digits : " + str(res))